import React, {useState} from 'react'

function Player({initialName, symbol, isActive, onChangeName}) {
    const [playerName, setPlayerName] = useState(initialName);
    const [isEditing, setIsEditing] = useState(false);//it is used for button
    
    function handleEditClick() {
        setIsEditing(editing => !editing); //we can also write it as setIsEditing(isEditing => isEditing)
        if(isEditing) {
            onChangeName(symbol, playerName);
        }
    }

    function handleChange(event) {
        setPlayerName(event.target.value);
    }

    let editablePlayerName = <span className="player-name">{playerName}</span>
    // let btnCaption = 'Edit';

    if(isEditing) {
        editablePlayerName = <input type='text' required value = {playerName} onChange={handleChange} />;
        // btnCaption = 'Save'
    }


  return (
    <li className={isActive ? 'active' : undefined}>
          <span className="player">
            {editablePlayerName}
            <span className="player-symbol">{symbol}</span>
          </span>
          <button onClick={handleEditClick}>{isEditing ? 'Save' : 'Edit'}</button>
          
          {/* <button onClick={handleEditClick}>{btnCaption}</button> */}
          {/* we can also use the button method as:
           <button onClick={handleEditClick}>{isEditing ? 'Save' : 'Edit'}</button>
           and remove : let btnCaption = 'Edit';
            and btnCaption = 'Save'
           */}

    </li>
  );
}

export default Player